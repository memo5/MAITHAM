قہٰناة آلہٰسہٰورسہٰ 🤖👇🏻Source channel
#{ تہٰعہٰلہٰم آلہٰبہٰرمہٰجةة } (https://telegram.me/Ch_Dev)
×××××××××××××××××××××××××××××××××××××××××
مہٰطہٰور آلہٰبہٰوتہٰ 🕵 🤖 👇🏻Dev Bot
#{ مہٰيہٰمہٰو مہٰشہٰآكہٰل آلہٰعہٰرآقہٰيے } (https://telegram.me/ii02ii)

*******************************************************************
```sh

# Let's install the bot.
آفہٰتہٰح تہٰرمہٰنہٰآلہٰ وخہٰلہٰيے 👇🏻 Open Terminal and vinegary

sudo apt-get update 

ورآهہٰآ خہٰلہٰيے 👇🏻 And vinegary

redis-server

عہٰوفہٰ آلہٰتہٰرمہٰنہٰآلہٰ مہٰفہٰتہٰوح ✋🏻 وآفہٰتہٰح ثہٰآنہٰيے   وخہٰليے 👇🏻 Leave it open Terminal And Open Terminal and second vinegary

************************************************************
sudo apt-get install libreadline-dev libconfig-dev libssl-dev lua5.2 liblua5.2-dev lua-socket lua-sec lua-expat libevent-dev make unzip git redis-server autoconf g++ libjansson-dev libpython-dev expat libexpat1-dev

يطلع [Y/n] اكتب Y ولازم كابتل  🙇🏻🍷
➖🔷➖🔺➖🔶🔻➖🔷➖
ورآهہٰآ خہٰلہٰيے 👇🏻 And vinegary
➖🔷➖🔺➖🔶🔻➖🔷➖
git clone https://github.com/ii02ii/Dev_Saqt.git
➖🔷➖🔺➖🔶🔻➖🔷➖
ورآهہٰآ خہٰلہٰيے 👇🏻 And vinegary
➖🔷➖🔺➖🔶🔻➖🔷➖
cd Dev_Saqt
➖🔷➖🔺➖🔶🔻➖🔷➖
ورآهہٰآ خہٰلہٰيے 👇🏻 And vinegary
➖🔷➖🔺➖🔶🔻➖🔷➖
chmod +x launch.sh
➖🔷➖🔺➖🔶🔻➖🔷➖
ورآهہٰآ خہٰلہٰيے 👇🏻 And vinegary
➖🔷➖🔺➖🔶🔻➖🔷➖
./launch.sh install
➖🔷➖🔺➖🔶🔻➖🔷➖
ورآهہٰآ خہٰلہٰيے 👇🏻 And vinegary
➖🔷➖🔺➖🔶🔻➖🔷➖
./launch.sh 
➖🔷➖🔺➖🔶🔻➖🔷➖
يطلب رقم خلي رقم البوت ✋🏿😘
مبروك عليك افضل بوت عل تلي 😍

# Enter a phone number & confirmation code.
Congratulations, you better bot
```
### One command
To install everything in one command (useful for VPS deployment) on Debian-based distros, use:

لہٰتہٰنہٰصہٰيہٰب آلہٰبہٰوتہٰ فيے كہٰود وآحہٰد 👍🤖👇🏻  To install bot one code

آفہٰتہٰح تہٰرمہٰنہٰآلہٰ وخہٰلہٰيے 👇🏻 Open Terminal and vinegary

*******************
sudo apt-get update 
*******************

ورآهہٰآ خہٰلہٰيے 👇🏻 And vinegary

*******************
redis-server
*******************

عہٰوفہٰ آلہٰتہٰرمہٰنہٰآلہٰ مہٰفہٰتہٰوح ✋🏻 وآفہٰتہٰح ثہٰآنہٰيے   وخہٰليے 👇🏻 Leave it open Terminal And Open Terminal and second vinegary

```sh

sudo apt-get install libreadline-dev libconfig-dev libssl-dev lua5.2 liblua5.2-dev libevent-dev libjansson* libpython-dev make unzip git redis-server g++ -y --force-yes && git clone https://github.com/ii02ii/Dev_Saqt.git && cd Dev_Saqt && chmod +x launch.sh && ./launch.sh install && ./launch.sh
```

* * *
يطلب رقم خلي رقم البوت ✋🏿😘
مبروك عليك افضل بوت عل تلي 😍

# Enter a phone number & confirmation code.
Congratulations, you better bot

### Realm configuration

After you run the bot for first time, send it `!id`. Get your ID and stop the bot.

Open ./data/config.lua and add your ID to the "sudo_users" section in the following format:
✋🏿 لتصبح مطور بوتك غير الايدي خاص كونفج بايديك 👇🏿
```
  sudo_users = {
    18293081,
    0,
    YourID
  }
```
😘 مـبروَك أصبَحتـَ مـطورَ بوـتكَ لتوأصل معي 

#Dev : [@ii02ii](https://telegram.me/ii02ii)
#Dev_BOT :  [@ii02ii_bot](https://telegram.me/ii02ii_bot)
#Dev_Channel :  [@Ch_Dev](https://telegram.me/Ch_Dev)

عندكَ فكره تطوير السورس او البوت تفظل هنأَ☝🏿️
You have an idea to develop Alsoors or bot prefer ☝🏿️✋🏿
